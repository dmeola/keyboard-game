/* Stage + controls for the redesigned Pip owl */
const { useState, useEffect, useRef, useCallback } = React;

const EXPRESSIONS = [
  { id: 'idle',      label: 'Idle',      msg: "Hi! I'm Pip!" },
  { id: 'happy',     label: 'Happy',     msg: 'Yay! Nice press! 🎵' },
  { id: 'excited',   label: 'Excited',   msg: 'Wooo! You did it!' },
  { id: 'curious',   label: 'Curious',   msg: 'Hmm… can you find the A?' },
  { id: 'nudge',     label: 'Nudge',     msg: 'Pssst… try this key!' },
  { id: 'celebrate', label: 'Celebrate', msg: 'WOOHOO! 🎉 Amazing!' },
];

const THEME_ORDER = ['sky', 'teal', 'berry', 'grass', 'sunny'];

/* faithful per-letter lines (matches the real app's tone) */
const LETTER_MESSAGES = {
  A:['excited',"A is for Apple! 🍎 A says “ahh”!"], B:['happy',"B is for Balloon! 🎈 B goes “buh”!"],
  C:['curious',"C is for Cat! 🐱 C says “kuh”!"],   D:['happy',"D is for Dog! 🐶 D goes “duh”!"],
  E:['excited',"E is for Elephant! 🐘 E says “ehh”!"], F:['curious',"F is for Fish! 🐟 F goes “fff”!"],
  G:['happy',"G is for Grapes! 🍇 G says “guh”!"], H:['idle',"H is for Hat! 🎩 H goes “huh”!"],
  I:['excited',"I is for Ice Cream! 🍦 I says “eye”!"], J:['curious',"J is for Jellyfish! 🪼 J goes “juh”!"],
  K:['happy',"K is for Kite! 🪁 K says “kuh”!"], L:['excited',"L is for Lion! 🦁 L goes “lll”!"],
  M:['happy',"M is for Moon! 🌙 M says “mmm”!"], N:['curious',"N is for Nose! 👃 N goes “nnn”!"],
  O:['excited',"O is for Orange! 🍊 O says “ohh”!"], P:['happy',"P is for Penguin! 🐧 P goes “puh”!"],
  Q:['curious',"Q is for Queen! 👑 Q says “kwuh”!"], R:['excited',"R is for Rainbow! 🌈 R goes “rrr”!"],
  S:['happy',"S is for Star! ⭐ S says “sss”!"], T:['excited',"T is for Train! 🚂 T goes “tuh”!"],
  U:['curious',"U is for Umbrella! ☂️ U says “uhh”!"], V:['excited',"V is for Volcano! 🌋 V goes “vvv”!"],
  W:['happy',"W is for Watermelon! 🍉 W says “wuh”!"], X:['curious',"X is for Xylophone! 🎵 X goes “ksss”!"],
  Y:['happy',"Y is for Yarn! 🧶 Y says “yuh”!"], Z:['excited',"Z is for Zebra! 🦓 Z says “zzz”!"],
};

function SpeechBubble({ text, msgKey }) {
  return (
    <div className="bubble" key={msgKey}>
      <p>{text}</p>
      <span className="bubble-tail" />
    </div>
  );
}

function App() {
  const [expression, setExpression] = useState('idle');
  const [theme, setTheme] = useState('sky');
  const [message, setMessage] = useState(EXPRESSIONS[0].msg);
  const [msgKey, setMsgKey] = useState(0);
  const [blink, setBlink] = useState(false);
  const revertRef = useRef(null);

  const say = useCallback((expr, msg) => {
    setExpression(expr);
    setMessage(msg);
    setMsgKey((k) => k + 1);
  }, []);

  // blink loop (only meaningful for idle/curious where eyes are open)
  useEffect(() => {
    let t;
    const loop = () => {
      setBlink(true);
      setTimeout(() => setBlink(false), 130);
      t = setTimeout(loop, 2600 + Math.random() * 2400);
    };
    t = setTimeout(loop, 1800);
    return () => clearTimeout(t);
  }, []);

  // key-press demo
  useEffect(() => {
    const onKey = (e) => {
      const k = e.key.toUpperCase();
      if (LETTER_MESSAGES[k]) {
        e.preventDefault();
        const [expr, msg] = LETTER_MESSAGES[k];
        say(expr, msg);
        clearTimeout(revertRef.current);
        revertRef.current = setTimeout(() => say('idle', "Press any key to play!"), 3200);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [say]);

  const pickExpression = (ex) => {
    clearTimeout(revertRef.current);
    say(ex.id, ex.msg);
  };

  return (
    <div className="stage">
      <div className="bg" aria-hidden="true" />

      <header className="head">
        <h1>Meet Pip <span className="head-sub">— redesigned owl mascot</span></h1>
      </header>

      <div className="hero">
        <SpeechBubble text={message} msgKey={msgKey} />
        <div className="owl-wrap">
          <Owl expression={expression} theme={theme} blink={blink} />
        </div>
        <p className="hint">▸ Type any letter key to see Pip react</p>
      </div>

      <div className="panel">
        <div className="panel-group">
          <span className="panel-label">Expression</span>
          <div className="chips">
            {EXPRESSIONS.map((ex) => (
              <button key={ex.id}
                className={`chip ${expression === ex.id ? 'on' : ''}`}
                onClick={() => pickExpression(ex)}>
                {ex.label}
              </button>
            ))}
          </div>
        </div>

        <div className="panel-group">
          <span className="panel-label">Color</span>
          <div className="swatches">
            {THEME_ORDER.map((id) => (
              <button key={id}
                className={`swatch ${theme === id ? 'on' : ''}`}
                style={{ background: window.OWL_THEMES[id].body, borderColor: window.OWL_THEMES[id].outline }}
                onClick={() => setTheme(id)}
                aria-label={window.OWL_THEMES[id].label}
                title={window.OWL_THEMES[id].label} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);

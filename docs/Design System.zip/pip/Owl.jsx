/* Pip the Owl — redesigned mascot
   Round, bright, bouncy. Soft feather tufts, big sparkly eyes with a hint of
   owl amber, a clean candy-corn beak, real rounded wings, cream tummy, tiny feet. */

const OWL_THEMES = {
  sky:   { body:'#54C5F0', dark:'#28B0E6', wing:'#2BA1D8', face:'#CDEDFB', outline:'#1E93CE', beakTop:'#FFB23E', beakBot:'#F98C16', feet:'#FB9A1E', label:'Sky' },
  teal:  { body:'#39D2C6', dark:'#1CBDB1', wing:'#15A89C', face:'#C6F2EC', outline:'#0E9E92', beakTop:'#FFB23E', beakBot:'#F98C16', feet:'#FB9A1E', label:'Teal' },
  berry: { body:'#FF8C8C', dark:'#FF6B6B', wing:'#F25C5C', face:'#FFDCD8', outline:'#E84C4C', beakTop:'#FFC24D', beakBot:'#FB9A1E', feet:'#F98C16', label:'Berry' },
  grass: { body:'#74CE7E', dark:'#54B85F', wing:'#46A852', face:'#CDEFCF', outline:'#3E9A48', beakTop:'#FFB23E', beakBot:'#F98C16', feet:'#FB9A1E', label:'Grass' },
  sunny: { body:'#FFC04D', dark:'#FFA92B', wing:'#F6921A', face:'#FFE9C2', outline:'#E8830C', beakTop:'#FF8A7E', beakBot:'#F2554A', feet:'#F2554A', label:'Sunny' },
};

const OWL_CONST = {
  belly:  '#FFF4CF',
  bellyLn:'#F4E2A6',
  eyeWhite:'#FFFFFF',
  iris:   '#F7B733',
  irisIn: '#E89A0E',
  pupil:  '#2A2A52',
  cheek:  '#FF8A80',
};

/* per-expression eye + pose config */
function eyeConfig(expression) {
  switch (expression) {
    case 'happy':     return { left:'smile', right:'smile', look:[0,0] };
    case 'excited':   return { left:'wide',  right:'wide',  look:[0,-1] };
    case 'curious':   return { left:'open',  right:'open',  look:[5,-6] };
    case 'nudge':     return { left:'smile', right:'open',  look:[6,2] };   // winking left
    case 'celebrate': return { left:'star',  right:'star',  look:[0,-2] };
    default:          return { left:'open',  right:'open',  look:[0,0] };   // idle
  }
}

function Eye({ cx, cy, mode, look, blink }) {
  const lx = Math.max(-5, Math.min(5, look[0]));
  const ly = Math.max(-5, Math.min(5, look[1]));

  // closed-smile arc (happy / wink)
  if (mode === 'smile') {
    return (
      <path d={`M ${cx-20} ${cy+5} Q ${cx} ${cy-16} ${cx+20} ${cy+5}`}
        stroke={OWL_CONST.pupil} strokeWidth="7" strokeLinecap="round" fill="none" />
    );
  }

  // blink overrides open/wide/star → thin happy line
  if (blink) {
    return (
      <path d={`M ${cx-19} ${cy} Q ${cx} ${cy+7} ${cx+19} ${cy}`}
        stroke={OWL_CONST.pupil} strokeWidth="6.5" strokeLinecap="round" fill="none" />
    );
  }

  const wide = mode === 'wide' || mode === 'star';
  const scl = wide ? 30 : 28;
  const irisR = wide ? 25 : 23;
  const pupR = wide ? 16 : 17;

  return (
    <g>
      <circle cx={cx} cy={cy} r={scl} fill={OWL_CONST.eyeWhite} />
      <g transform={`translate(${lx} ${ly})`}>
        <circle cx={cx} cy={cy} r={irisR} fill={OWL_CONST.iris} />
        <circle cx={cx} cy={cy} r={irisR} fill="none" stroke={OWL_CONST.irisIn} strokeWidth="2" opacity="0.5" />
        <circle cx={cx} cy={cy} r={pupR} fill={OWL_CONST.pupil} />
        {/* sparkle highlights */}
        <circle cx={cx-8} cy={cy-9} r="7" fill="#fff" />
        <circle cx={cx+7} cy={cy+7} r="3.2" fill="#fff" opacity="0.9" />
      </g>
      {/* star eyes for celebrate */}
      {mode === 'star' && (
        <path transform={`translate(${cx} ${cy}) scale(1.5)`}
          d="M0,-8 Q1.6,-1.6 8,0 Q1.6,1.6 0,8 Q-1.6,1.6 -8,0 Q-1.6,-1.6 0,-8 Z"
          fill="#FFE36B" stroke="#F7B733" strokeWidth="1" />
      )}
    </g>
  );
}

function Beak({ open }) {
  return (
    <g>
      {/* candy-corn beak: rounded downward, two-tone, no center line */}
      <path d="M 107 137 Q 120 133 133 137 L 127 153 Q 120 159 113 153 Z"
        fill="var(--beak-top)" />
      <path d="M 110 147 Q 120 151 130 147 L 127 153 Q 120 159 113 153 Z"
        fill="var(--beak-bot)" />
      {open && (
        <ellipse cx="120" cy="159" rx="8" ry="6" fill="#C84A38" />
      )}
    </g>
  );
}

function Owl({ expression = 'idle', theme = 'sky', blink = false }) {
  const t = OWL_THEMES[theme] || OWL_THEMES.sky;
  const cfg = eyeConfig(expression);
  const openBeak = expression === 'excited' || expression === 'celebrate';
  const sparkle = expression === 'excited' || expression === 'celebrate';
  const confetti = expression === 'celebrate';

  return (
    <svg viewBox="0 0 240 250" width="100%" height="100%" className="owl-svg" aria-hidden="true"
      style={{
        '--beak-top': t.beakTop, '--beak-bot': t.beakBot,
        overflow: 'visible',
      }}>
      <g className={`owl-root owl-${expression}`} style={{ transformOrigin: '120px 205px' }}>

        {/* soft ground shadow */}
        <ellipse cx="120" cy="232" rx="62" ry="11" fill="#000" opacity="0.10" className="owl-shadow" />

        {/* feet */}
        <g stroke={t.feet} strokeWidth="6" strokeLinecap="round" fill="none">
          <path d="M 100 214 l -7 11 M 100 214 l 0 13 M 100 214 l 7 11" />
          <path d="M 140 214 l -7 11 M 140 214 l 0 13 M 140 214 l 7 11" />
        </g>

        {/* ear tufts — soft rounded feather peaks (behind head) */}
        <path className="tuft tuft-l" d="M 92 70 C 76 62 68 44 73 33 C 88 41 100 56 106 72 Z"
          fill={t.body} stroke={t.outline} strokeWidth="3" strokeLinejoin="round" />
        <path className="tuft tuft-r" d="M 148 70 C 164 62 172 44 167 33 C 152 41 140 56 134 72 Z"
          fill={t.body} stroke={t.outline} strokeWidth="3" strokeLinejoin="round" />
        <path d="M 90 66 C 80 58 75 47 77 40 C 86 47 94 57 98 67 Z" fill="#fff" opacity="0.18" />
        <path d="M 150 66 C 160 58 165 47 163 40 C 154 47 146 57 142 67 Z" fill="#fff" opacity="0.18" />

        {/* wings — rounded, with feather scallops at the tip (behind body edges) */}
        <path className="wing wing-l" d="M 54 116 C 30 124 26 168 40 192 C 46 184 50 190 56 180 C 60 187 66 184 68 174 C 60 152 58 130 54 116 Z"
          fill={t.wing} stroke={t.outline} strokeWidth="3" strokeLinejoin="round" />
        <path className="wing wing-r" d="M 186 116 C 210 124 214 168 200 192 C 194 184 190 190 184 180 C 180 187 174 184 172 174 C 180 152 182 130 186 116 Z"
          fill={t.wing} stroke={t.outline} strokeWidth="3" strokeLinejoin="round" />

        {/* body — tapered egg: narrower head, wider belly */}
        <path d="M 120 54
                 C 164 54 190 90 196 138
                 C 202 188 170 226 120 226
                 C 70 226 38 188 44 138
                 C 50 90 76 54 120 54 Z"
          fill={t.body} stroke={t.outline} strokeWidth="3" strokeLinejoin="round" />

        {/* belly / chest bib */}
        <path d="M 120 120
                 C 86 120 70 142 70 170
                 C 70 198 94 214 120 214
                 C 146 214 170 198 170 170
                 C 170 142 154 120 120 120 Z"
          fill={OWL_CONST.belly} />
        <path d="M 86 150 Q 103 142 120 150 Q 137 142 154 150" stroke={OWL_CONST.bellyLn} strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.8" />
        <path d="M 90 168 Q 105 160 120 168 Q 135 160 150 168" stroke={OWL_CONST.bellyLn} strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.7" />
        <path d="M 96 186 Q 108 179 120 186 Q 132 179 144 186" stroke={OWL_CONST.bellyLn} strokeWidth="2.5" fill="none" strokeLinecap="round" opacity="0.6" />

        {/* facial disc — lighter tint around the eyes */}
        <ellipse cx="120" cy="112" rx="66" ry="52" fill={t.face} opacity="0.85" />

        {/* eyebrow (curious) */}
        {expression === 'curious' && (
          <path d="M 132 72 Q 150 64 166 72" stroke={t.outline} strokeWidth="4.5" fill="none" strokeLinecap="round" className="brow" />
        )}

        {/* eyes */}
        <Eye cx={90}  cy={112} mode={cfg.left}  look={cfg.look} blink={blink && cfg.left === 'open'} />
        <Eye cx={150} cy={112} mode={cfg.right} look={cfg.look} blink={blink && cfg.right === 'open'} />

        {/* cheeks */}
        <ellipse cx="66" cy="138" rx="15" ry="9" fill={OWL_CONST.cheek} opacity={expression === 'happy' || expression === 'celebrate' ? 0.65 : 0.42} />
        <ellipse cx="174" cy="138" rx="15" ry="9" fill={OWL_CONST.cheek} opacity={expression === 'happy' || expression === 'celebrate' ? 0.65 : 0.42} />

        {/* beak */}
        <Beak open={openBeak} />

        {/* sparkles */}
        {sparkle && [
          { x: 36, y: 70, s: 1.1, d: '0s' },
          { x: 206, y: 84, s: 1.4, d: '.3s' },
          { x: 200, y: 150, s: 0.9, d: '.6s' },
          { x: 30, y: 150, s: 1.0, d: '.45s' },
        ].map((p, i) => (
          <path key={i} className="spark"
            transform={`translate(${p.x} ${p.y}) scale(${p.s})`}
            style={{ animationDelay: p.d }}
            d="M0,-9 Q1.7,-1.7 9,0 Q1.7,1.7 0,9 Q-1.7,1.7 -9,0 Q-1.7,-1.7 0,-9 Z"
            fill="#FFE36B" stroke="#F7B733" strokeWidth="1" />
        ))}

        {/* confetti (celebrate) */}
        {confetti && ['#FF6B63','#54C5F0','#74CE7E','#FFC04D','#FF8C8C'].map((c, i) => (
          <rect key={i} className="confetti" x={48 + i * 36} y="28" width="9" height="9" rx="2"
            fill={c} style={{ animationDelay: `${i * 0.12}s` }} transform={`rotate(${i * 25} ${52 + i * 36} 32)`} />
        ))}
      </g>
    </svg>
  );
}

window.Owl = Owl;
window.OWL_THEMES = OWL_THEMES;
